'use strict';

require('./BitmapText');
