<!-- See CONTRIBUTING.md for guidelines on reporting issues. Delete any lines as needed.-->

Your issue may already be reported! Please search [existing issues](../) before creating one.

<!-- Bug Report (delete if not applicable) -->

### Expected Behavior

### Current Behavior

### Possible Solution

### Steps to Reproduce

### Environment

- `pixi.js` version: _e.g. 4.7.1_
- Browser: _e.g. Chrome 67_
- Device: _e.g. Desktop_
